package api

import (
	"encoding/json"
	"log"
	"net/http"
	"reflect"
	"runtime"
	"strings"

	"github.com/kptm-tools/core-service/pkg/middleware"

	"github.com/kptm-tools/core-service/pkg/interfaces"
)

type APIServer struct {
	listenAddr string

	healthHandlers       interfaces.IHealthcheckHandlers
	hostHandlers         interfaces.IHostHandlers
	authHandlers         interfaces.IAuthHandlers
	tenantHandlers       interfaces.ITenantHandlers
	scanHandlers         interfaces.IScanHandlers
	vulnHandlers         interfaces.IVulnerabilityHandlers
	scanScheduleHandlers interfaces.IScanScheduleHandlers
	scanHub              interfaces.IHub
	reportHub            interfaces.IHub
}

type APIError struct {
	Error string `json:"error"`
}

type APIFunc func(http.ResponseWriter, *http.Request) error

func NewAPIServer(
	listenAddr string,
	heHandlers interfaces.IHealthcheckHandlers,
	hoHandlers interfaces.IHostHandlers,
	teHandlers interfaces.ITenantHandlers,
	aHandlers interfaces.IAuthHandlers,
	sHandlers interfaces.IScanHandlers,
	vHandlers interfaces.IVulnerabilityHandlers,
	ssHandlers interfaces.IScanScheduleHandlers,
	scanHub interfaces.IHub,
	reportHub interfaces.IHub,
) *APIServer {
	return &APIServer{
		listenAddr: listenAddr,

		healthHandlers:       heHandlers,
		hostHandlers:         hoHandlers,
		authHandlers:         aHandlers,
		tenantHandlers:       teHandlers,
		scanHandlers:         sHandlers,
		vulnHandlers:         vHandlers,
		scanScheduleHandlers: ssHandlers,
		scanHub:              scanHub,
		reportHub:            reportHub,
	}
}

func (s *APIServer) Init() http.Server {
	router := http.NewServeMux()

	go s.scanHub.Run()
	go s.reportHub.Run()

	router.HandleFunc("GET /healthcheck",
		makeHTTPHandlerFunc(s.healthHandlers.Healthcheck),
	)

	// Auth routes
	router.HandleFunc("POST /api/login", makeHTTPHandlerFunc(s.authHandlers.Login))
	router.HandleFunc("POST /api/forgot-password", makeHTTPHandlerFunc(s.authHandlers.ForgotPassword))
	router.HandleFunc("POST /api/change-password", makeHTTPHandlerFunc(s.authHandlers.ChangePassword))
	router.HandleFunc("POST /api/users", makeHTTPHandlerFunc(s.authHandlers.RegisterUser))
	router.HandleFunc("GET /api/users/verify", makeHTTPHandlerFunc(s.authHandlers.VerifyEmail))
	router.HandleFunc("POST /api/tenants", makeHTTPHandlerFunc(s.authHandlers.RegisterTenant))
	router.HandleFunc("GET /api/users/{id}", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.authHandlers.GetUser), "getUser"))

	router.HandleFunc("POST /api/hosts", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.hostHandlers.CreateHost), "newHost"))
	router.HandleFunc("POST /api/hosts/validate-host", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.hostHandlers.ValidateHost), "validateHost"))
	router.HandleFunc("POST /api/hosts/validate-alias", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.hostHandlers.ValidateAlias), "validateAlias"))
	router.HandleFunc("GET /api/hosts", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.hostHandlers.GetHosts), "getHosts"))
	router.HandleFunc("GET /api/hosts/{id}", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.hostHandlers.GetHostByID), "getHostByID"))
	router.HandleFunc("DELETE /api/hosts/{id}", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.hostHandlers.DeleteHostByID), "deleteHostByID"))
	router.HandleFunc("PATCH /api/hosts/{id}", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.hostHandlers.PatchHostByID), "patchHostByID"))
	router.HandleFunc("GET /tenants", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.tenantHandlers.GetTenants), "tenants"))

	router.HandleFunc("POST /api/scans", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.scanHandlers.CreateScan), "createScans"))
	router.HandleFunc("POST /api/scans/{id}/cancel", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.scanHandlers.CancelScanByID), "cancelScanByID"))
	router.HandleFunc("GET /api/scans/{id}/insights", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.scanHandlers.GetScanInsightsByID), "getScanInsightsByID"))
	router.HandleFunc("GET /api/scans/{id}/vulnerabilities", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.scanHandlers.GetScanVulnerabilities), "getScanVulnerabilities"))
	router.HandleFunc("GET /api/scans/{id}/vulnerabilities/summary", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.scanHandlers.GetScanVulnerabilitySummaryByID), "getScanVulnerabilitySummaryByID"))

	router.HandleFunc("GET /api/scorecard-trends", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.scanHandlers.GetScoreCardTrends), "getScoreCardTrends"))
	router.HandleFunc("DELETE /api/scan-schedules/{id}", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.scanScheduleHandlers.DeleteScanSchedule), "deleteScheduleByID"))
	router.HandleFunc("PATCH /api/scan-schedules/{id}", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.scanScheduleHandlers.PatchScanSchedule), "patchScheduleByID"))
	router.HandleFunc("GET /api/scan-schedules", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.scanScheduleHandlers.GetScanSchedules), "getSchedules"))

	router.HandleFunc("GET /api/reports", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.scanHandlers.GetReports), "getAllTenantReports"))

	router.HandleFunc("GET /api/vulnerabilities/{id}", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.vulnHandlers.GetVulnerability), "getVulnerability"))
	router.HandleFunc("POST /api/vulnerabilities/{id}/comment", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.vulnHandlers.CreateVulnerabilityComment), "createVulnerabilityComment"))
	router.HandleFunc("PATCH /api/vulnerabilities/{id}/comment", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.vulnHandlers.PatchVulnerabilityComment), "editVulnerabilityComment"))
	router.HandleFunc("DELETE /api/vulnerabilities/{id}/comment", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.vulnHandlers.DeleteVulnerabilityComment), "deleteVulnerabilityComment"))

	router.HandleFunc("GET /api/dashboard", s.authHandlers.WithAuth(makeHTTPHandlerFunc(s.tenantHandlers.GetDashboard), "getDashboard"))

	router.HandleFunc("/ws/scan", s.scanHub.Serve)
	router.HandleFunc("/ws/report/", s.reportHub.Serve)

	stack := middleware.CreateStack(
		middleware.Logging,
		middleware.CheckCORS,
	)
	log.Println("Server listening on port: ", s.listenAddr)
	return http.Server{
		Addr: s.listenAddr,

		Handler: stack(router),
	}
}

// This function wraps our APIFunc struct so we can handle errors gracefully
func makeHTTPHandlerFunc(f APIFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		err := f(w, r)
		if err != nil {
			WriteJSON(w, http.StatusInternalServerError, APIError{Error: err.Error()})
		}
	}
}

func WriteJSON(w http.ResponseWriter, status int, v any) error {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)               // Write the status
	return json.NewEncoder(w).Encode(v) // To encode anything
}

func UnmarshalGenericJSON(stringBytes []byte) (map[string]interface{}, error) {
	// This method receives an array of bytes and unmarshals them into a JSON
	m := map[string]interface{}{}

	if err := json.Unmarshal(stringBytes, &m); err != nil {
		return nil, err
	}
	return m, nil
}

func GetFunctionName(i interface{}) string {
	strs := strings.Split(runtime.FuncForPC(reflect.ValueOf(i).Pointer()).Name(), ".")
	return strs[len(strs)-1]
}
